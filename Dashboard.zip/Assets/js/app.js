import './controller/canteenController.js'
import './controller/scheduleController.js'
import './controller/weatherController.js'
import './controller/renderClock.js'
